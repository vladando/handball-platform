"""
collector.py — RSS + scraper ingestion module.
Pulls real article text from Balkan news portals into text_samples.
No author metadata stored — title + body text only.
"""

import uuid
import time
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger("collector")

# ─── FEED REGISTRY ────────────────────────────────────────────────────────────

RSS_FEEDS = [
    ("src_04", "Klix.ba",          "https://www.klix.ba/rss"),
    ("src_04", "Klix.ba Vijesti",  "https://www.klix.ba/vijesti/rss"),
    ("src_04", "Klix.ba Biznis",   "https://www.klix.ba/biznis/rss"),
    ("src_06", "N1 Info BiH",      "https://n1info.ba/feed/"),
    ("src_05", "Vijesti.ba",       "https://www.vijesti.ba/rss"),
    ("src_07", "Slobodna Bosna",   "https://www.slobodna-bosna.ba/feed/rss"),
    ("src_01", "Nezavisne",        "https://www.nezavisne.com/rss.xml"),
    ("src_02", "Glas Srpske",      "https://www.glassrpske.com/rss"),
    ("src_10", "Hayat",            "https://hayat.ba/feed/"),
]

# ─── COLLECTOR CLASS ──────────────────────────────────────────────────────────

class Collector:
    def __init__(self, db_path: str = "narrative_analytics.duckdb"):
        self.db_path = db_path
        self._feedparser = None
        self._requests   = None

    def _get_feedparser(self):
        if self._feedparser is None:
            import feedparser
            self._feedparser = feedparser
        return self._feedparser

    def _get_requests(self):
        if self._requests is None:
            import requests as req
            self._requests = req
        return self._requests

    def _get_connection(self):
        import duckdb
        return duckdb.connect(self.db_path)

    def _entry_to_text(self, entry) -> Optional[str]:
        """Extract best available text from a feed entry."""
        parts = []
        title = entry.get("title", "").strip()
        if title:
            parts.append(title)
        # Try content first, then summary
        content = ""
        if hasattr(entry, "content") and entry.content:
            content = entry.content[0].get("value", "")
        if not content:
            content = entry.get("summary", "")
        if content:
            # Strip basic HTML tags
            import re
            content = re.sub(r"<[^>]+>", " ", content)
            content = re.sub(r"\s+", " ", content).strip()
            parts.append(content)
        result = " ".join(parts)
        return result if len(result) > 60 else None

    def _entry_date(self, entry) -> datetime:
        """Parse published date from feed entry."""
        try:
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                return datetime(*entry.published_parsed[:6])
        except Exception:
            pass
        return datetime.now()

    def collect_rss(self) -> dict:
        """Pull all RSS feeds and insert new samples. Returns stats dict."""
        fp = self._get_feedparser()
        con = self._get_connection()
        inserted = 0
        skipped  = 0
        errors   = 0

        for source_id, source_name, url in RSS_FEEDS:
            try:
                logger.info(f"[RSS] Fetching {source_name}...")
                feed = fp.parse(url)

                if feed.get("bozo") and not feed.entries:
                    logger.warning(f"[RSS] Bad feed: {source_name}")
                    errors += 1
                    continue

                for entry in feed.entries:
                    text = self._entry_to_text(entry)
                    if not text:
                        skipped += 1
                        continue

                    pub_date = self._entry_date(entry)
                    sample_id = str(uuid.uuid4())

                    try:
                        con.execute("""
                            INSERT INTO text_samples
                                (sample_id, source_id, ingested_at,
                                 published_at, raw_text, word_count, is_processed)
                            VALUES (?, ?, ?, ?, ?, ?, FALSE)
                        """, (
                            sample_id, source_id, datetime.now(),
                            pub_date, text, len(text.split())
                        ))
                        inserted += 1
                    except Exception:
                        # Duplicate or constraint error — skip silently
                        skipped += 1

                time.sleep(0.5)  # Be polite to servers

            except Exception as e:
                logger.error(f"[RSS] Error fetching {source_name}: {e}")
                errors += 1

        con.close()
        logger.info(f"[RSS] Done — inserted: {inserted}, skipped: {skipped}, errors: {errors}")
        return {"inserted": inserted, "skipped": skipped, "errors": errors}

    def get_unprocessed_count(self) -> int:
        """Return count of samples not yet topic-assigned."""
        try:
            con = self._get_connection()
            count = con.execute(
                "SELECT COUNT(*) FROM text_samples WHERE is_processed = FALSE"
            ).fetchone()[0]
            con.close()
            return count
        except Exception:
            return 0

    def get_total_count(self) -> int:
        """Return total sample count."""
        try:
            con = self._get_connection()
            count = con.execute("SELECT COUNT(*) FROM text_samples").fetchone()[0]
            con.close()
            return count
        except Exception:
            return 0


# Singleton
_collector = None

def get_collector(db_path: str = "narrative_analytics.duckdb") -> Collector:
    global _collector
    if _collector is None:
        _collector = Collector(db_path)
    return _collector


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    c = get_collector()
    stats = c.collect_rss()
    print(f"Inserted: {stats['inserted']} | Skipped: {stats['skipped']} | Errors: {stats['errors']}")
